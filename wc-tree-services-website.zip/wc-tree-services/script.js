// Mobile menu toggle
const toggle = document.querySelector('.mobile-toggle');
const nav = document.querySelector('.nav');

if (toggle && nav) {
  toggle.addEventListener('click', () => {
    nav.classList.toggle('active');
  });

  // Close menu when a link is clicked
  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('active');
    });
  });
}

// Smooth header background on scroll
const header = document.querySelector('.header');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    header.style.background = 'rgba(13, 59, 30, 0.98)';
    header.style.boxShadow = '0 4px 20px rgba(0,0,0,0.2)';
  } else {
    header.style.background = 'rgba(13, 59, 30, 0.95)';
    header.style.boxShadow = 'none';
  }
});
