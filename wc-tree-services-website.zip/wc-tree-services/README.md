# W&C Tree Services Website

A clean, modern, mobile-friendly single-page website created from the company flyer.

## How to Use

1. Open `index.html` in any web browser.
2. Or upload the entire folder to any web hosting (Netlify, Vercel, GitHub Pages, GoDaddy, etc.).

## Features

- Fully responsive (looks great on phones and desktops)
- All services and starting prices from the flyer
- Click-to-call phone number: **740-338-0078**
- Free estimate call-to-action throughout
- Professional green color scheme matching the flyer
- Fast loading – no external dependencies except Google Fonts

## Files

- `index.html` – Main page
- `styles.css` – All styling
- `script.js` – Mobile menu + small interactions

## Customization Tips

- To change the phone number, search for `740-338-0078` and replace it.
- To add real photos later, replace the emoji icons or add image sections.
- Colors can be adjusted in the `:root` section of `styles.css`.

---

**W&C Tree Services**  
Healthy Trees. Safe Property. Peace of Mind.  
📞 740-338-0078
